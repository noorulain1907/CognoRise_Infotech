// script.js

// Select elements
const display = document.getElementById('display');
const buttons = document.querySelectorAll('.btn');

// Variables to track the calculation
let currentInput = '';
let operator = '';
let firstValue = '';
let secondValue = '';

// Function to handle button clicks
buttons.forEach(button => {
  button.addEventListener('click', () => {
    const value = button.getAttribute('data-value');
    
    // Handle Clear button
    if (button.id === 'clear') {
      clearDisplay();
    } 
    // Handle Equals button
    else if (button.id === 'equals') {
      calculateResult();
    } 
    // Handle Operators
    else if (button.classList.contains('operator')) {
      setOperator(value);
    } 
    // Handle Numbers and Decimal Points
    else {
      appendValue(value);
    }
  });
});

// Function to append number/decimal point to the input
function appendValue(value) {
  currentInput += value;
  display.textContent = currentInput;
}

// Function to store the first value and set the operator
function setOperator(op) {
  if (currentInput === '') return;
  firstValue = currentInput;
  operator = op;
  currentInput = '';  // Reset input for the second value
}

// Function to perform the calculation and display the result
function calculateResult() {
  if (firstValue === '' || currentInput === '' || operator === '') return;

  secondValue = currentInput;
  let result;

  switch (operator) {
    case '+':
      result = parseFloat(firstValue) + parseFloat(secondValue);
      break;
    case '-':
      result = parseFloat(firstValue) - parseFloat(secondValue);
      break;
    case '*':
      result = parseFloat(firstValue) * parseFloat(secondValue);
      break;
    case '/':
      result = parseFloat(secondValue) !== 0 ? 
               parseFloat(firstValue) / parseFloat(secondValue) : 'Error';
      break;
  }

  display.textContent = result;
  currentInput = '';  // Reset input
  firstValue = '';    // Reset stored values
  operator = '';
}

// Function to clear the display and reset values
function clearDisplay() {
  currentInput = '';
  firstValue = '';
  secondValue = '';
  operator = '';
  display.textContent = '0';
}
