// Select DOM elements
const taskInput = document.getElementById('task-input');
const addTaskBtn = document.getElementById('add-task-btn');
const taskList = document.getElementById('task-list');

// Load tasks from localStorage on page load
document.addEventListener('DOMContentLoaded', loadTasks);

// Add event listeners
addTaskBtn.addEventListener('click', addTask);

// Function to add a new task
function addTask() {
  const taskText = taskInput.value.trim();
  if (taskText === '') return;

  const task = { text: taskText };
  saveTask(task); // Save to localStorage
  renderTask(task); // Render to UI
  taskInput.value = ''; // Clear input
}

// Function to render a single task
function renderTask(task) {
  const li = document.createElement('li');
  li.className = 'task';

  const span = document.createElement('span');
  span.textContent = task.text;

  const editBtn = document.createElement('button');
  editBtn.textContent = 'Edit';
  editBtn.addEventListener('click', () => editTask(li, task));

  const deleteBtn = document.createElement('button');
  deleteBtn.textContent = 'Delete';
  deleteBtn.addEventListener('click', () => deleteTask(li, task));

  li.appendChild(span);
  li.appendChild(editBtn);
  li.appendChild(deleteBtn);
  taskList.appendChild(li);
}

// Function to edit a task
function editTask(li, oldTask) {
  const newTaskText = prompt('Edit Task', oldTask.text);
  if (newTaskText && newTaskText.trim() !== '') {
    oldTask.text = newTaskText.trim();
    updateTasks();
    li.querySelector('span').textContent = newTaskText;
  }
}

// Function to delete a task
function deleteTask(li, task) {
  li.remove();
  removeTask(task);
}

// Save task to localStorage
function saveTask(task) {
  const tasks = JSON.parse(localStorage.getItem('tasks')) || [];
  tasks.push(task);
  localStorage.setItem('tasks', JSON.stringify(tasks));
}

// Remove task from localStorage
function removeTask(task) {
  let tasks = JSON.parse(localStorage.getItem('tasks')) || [];
  tasks = tasks.filter(t => t.text !== task.text);
  localStorage.setItem('tasks', JSON.stringify(tasks));
}

// Load tasks from localStorage and render them
function loadTasks() {
  const tasks = JSON.parse(localStorage.getItem('tasks')) || [];
  tasks.forEach(renderTask);
}

// Update all tasks in localStorage
function updateTasks() {
  const tasks = Array.from(taskList.children).map(li => ({
    text: li.querySelector('span').textContent
  }));
  localStorage.setItem('tasks', JSON.stringify(tasks));
}
